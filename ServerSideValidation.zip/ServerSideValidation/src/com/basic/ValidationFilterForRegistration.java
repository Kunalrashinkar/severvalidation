package com.basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


@WebFilter("/Validation")
public class ValidationFilterForRegistration implements Filter {

    
	public void destroy() {
		
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		//response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		String firstName =  request.getParameter("fn");
		String lastName =  request.getParameter("ln");
		String mobile =  request.getParameter("mob");
		
		if(firstName.equals(""))
		{
			//out.println("<center> First Name Cant be Empty</center>");
			
			String msg= "First Name Cant be Empty";
			request.setAttribute("msg", msg);
			
			//request.getRequestDispatcher("index.jsp").forward(request, response);
			
			
		}
		
		if(lastName.equals(""))
		{
			//out.println("<center> second Name Cant be Empty</center>");
			
			String msg= "second Name Cant be Empty";
			request.setAttribute("msg1", msg);
			
			//request.getRequestDispatcher("index.jsp").forward(request, response);
			
			
		}
		
		if(mobile.equals("")){
			String msg= "mobile Number Cant be Empty";
			request.setAttribute("msg2", msg);
			
			//request.getRequestDispatcher("index.jsp").forward(request, response);
			
		}
		
		if(firstName.equals("") || lastName.equals("") || mobile.equals("")){
			
			request.getRequestDispatcher("index.jsp").forward(request, response);

		}
		
		else{
			chain.doFilter(request, response);
		}
		
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
